<?php

require_once 'app/models/Member.php';

class membercontroller extends controller {
    private $member;

    public function __construct() {
        $database = new Database();
        $db = $database->getConnection();
        $this->member = new Member($db);
    }

    public function index() {
        $result = $this->member->read();
        $members = $result->fetchAll(PDO::FETCH_ASSOC);
        $this->view('members/index', ['members' => $members]);
    }

    public function create() {
        if ($_SERVER["REQUEST_METHOD"] == "POST") {
            $this->member->name = $_POST['name'];
            $this->member->birth_date = $_POST['birth_date'];
            $this->member->create();
            header("Location: /");
        } else {
            $this->view('members/create');
        }
    }

    public function edit($id) {
        if ($_SERVER["REQUEST_METHOD"] == "POST") {
            $this->member->id = $id;
            $this->member->name = $_POST['name'];
            $this->member->birth_date = $_POST['birth_date'];
            $this->member->update();
            header("Location: /");
        } else {
            $this->member->id = $id;
            $stmt = $this->member->read();
            $member = $stmt->fetch(PDO::FETCH_ASSOC);
            $this->view('members/edit', ['member' => $member]);
        }
    }

    public function delete($id) {
        $this->member->id = $id;
        $this->member->delete();
        header("Location: /");
    }

    public function view($id) {
        $this->member->id = $id;
        $stmt = $this->member->read();
        $member = $stmt->fetch(PDO::FETCH_ASSOC);
        $this->view('members/view', ['member' => $member]);
    }
}
