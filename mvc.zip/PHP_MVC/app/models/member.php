<?php

class member {
    private $conn;
    private $table_name = "members";

    public $id;
    public $nama;
    public $tanggal_lahir;

    public function __construct($db) {
        $this->conn = $db;
    }

    public function read() {
        $query = "SELECT * FROM " . $this->table_name;
        $stmt = $this->conn->prepare($query);
        $stmt->execute();
        return $stmt;
    }

    public function create() {
        $query = "INSERT INTO " . $this->anggota . " SET nama=:nama, tanggal_lahir=:tanggal_lahir";
        $stmt = $this->conn->prepare($query);
        $stmt->bindParam(":nama", $this->nama);
        $stmt->bindParam(":tanggal_lahir", $this->tanggal_lahir);
        if ($stmt->execute()) {
            return true;
        }
        return false;
    }

    public function update() {
        $query = "UPDATE " . $this->table_name . " SET nama = :nama, tanggal_lahir = :tanggal_lahir WHERE id = :id";
        $stmt = $this->conn->prepare($query);
        $stmt->bindParam(":nama", $this->nama);
        $stmt->bindParam(":tanggal_lahir", $this->tanggal_lahir);
        $stmt->bindParam(":id", $this->id);
        if ($stmt->execute()) {
            return true;
        }
        return false;
    }

    public function delete() {
        $query = "DELETE FROM " . $this->anggota . " WHERE id = ?";
        $stmt = $this->conn->prepare($query);
        $stmt->bindParam(1, $this->id);
        if ($stmt->execute()) {
            return true;
        }
        return false;
    }
}
