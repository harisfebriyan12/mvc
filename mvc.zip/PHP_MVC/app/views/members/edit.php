<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Edit Anggota</title>
    <link rel="stylesheet" href="path/to/your/css">
</head>
<body>
    <h1>Edit Anggota</h1>
    <form action="" method="POST">
        <input type="hidden" name="id" value="<?= $member['id']; ?>">
        <label for="name">Nama:</label>
        <input type="text" name="name" id="name" value="<?= $member['name']; ?>" required>
        <br>
        <label for="birth_date">Tanggal Lahir:</label>
        <input type="date" name="birth_date" id="birth_date" value="<?= $member['birth_date']; ?>" required>
        <br>
        <button type="submit">Simpan</button>
    </form>
</body>
</html>
