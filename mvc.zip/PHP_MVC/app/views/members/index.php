<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Daftar Anggota</title>
    <link rel="stylesheet" href="path/to/your/css">
</head>
<body>
    <h1>Daftar Anggota</h1>
    <a href="/members/create">Tambah Anggota</a>
    <table>
        <thead>
            <tr>
                <th>ID</th>
                <th>Nama</th>
                <th>Tanggal Lahir</th>
                <th>Detail</th>
            </tr>
        </thead>
        <tbody>
            <?php foreach ($members as $member): ?>
                <tr>
                    <td><?= $member['id']; ?></td>
                    <td><?= $member['nama']; ?></td>
                    <td><?= $member['tanggal_lahir']; ?></td>
                    <td>
                        <a href="/members/view/<?= $member['id']; ?>">VIEW</a>
                        <a href="/members/edit/<?= $member['id']; ?>">EDIT</a>
                        <a href="/members/delete/<?= $member['id']; ?>" onclick="return confirm('Are you sure?')">DELETE</a>
                    </td>
                </tr>
            <?php endforeach; ?>
        </tbody>
    </table>
</body>
</html>
