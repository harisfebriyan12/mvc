<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Detail Anggota</title>
    <link rel="stylesheet" href="path/to/your/css">
</head>
<body>
    <h1>Detail Anggota</h1>
    <p>ID: <?= $member['id']; ?></p>
    <p>Nama: <?= $member['name']; ?></p>
    <p>Tanggal Lahir: <?= $member['birth_date']; ?></p>
    <a href="/">Kembali ke Daftar Anggota</a>
</body>
</html>
